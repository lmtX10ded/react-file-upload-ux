import React from 'react'
import Spinner from './Spinner'

const Review = ({ children }) => <Spinner>Hold on for just a moment...</Spinner>

export default Review
