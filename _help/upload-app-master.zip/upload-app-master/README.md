# Upload App

https://medium.com/@jsmanifest/build-a-modern-customized-file-uploading-user-interface-in-react-with-plain-css-8a78bc92963a

https://jsmanifest.com/build-complex-custom-file-uploading-ui-in-react-with-plain-css/

https://dev.to/jsmanifest/build-a-complex-customized-file-uploading-user-interface-in-react-with-plain-css-5539
